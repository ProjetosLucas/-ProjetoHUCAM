WZGrapher Function Grapher

INSTALLATION:
If you haven't yet, download the ZIP file
wzgrapher.zip (german) or wzgrapher_e.zip (english)
from http://www.walterzorn.com/grapher/grapher_app.htm
and unzip it to the directory you wish, preferably however into a
separate folder inside your programs folder.


UNINSTALL:
To uninstall WZ.Grapher, just delete the file wz_grapher.exe
or the above mentioned subdirectory containing it.


RUN THE APPLICATION:
(Double-)click on wzgrapher.exe to start the application.
Window NT/2000/XP:
To complete installation when running WZ.Grapher the first time,
it's recommended to start the application at least once
with administrator rights.


WZG FILES:
Consider that the application - and also the .wzg file type -
is still under development.
Therefore backward-compatibility of .wzg files is not yet guaranteed -
it may happen that a newer version of the program can't open
an old .wzg file.


HOW TO MAIL ME:
English Version:  Help->About WZGrapher...
Deutsche Version: Hilfe->�ber WZGrapher...


Walter Zorn
Munich/Germany
